package com.springbootproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springbootproject.entity.Ecart;



public interface CartRepository extends JpaRepository<Ecart, Integer> {

}
