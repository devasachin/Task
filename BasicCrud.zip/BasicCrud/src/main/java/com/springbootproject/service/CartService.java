package com.springbootproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springbootproject.dao.CartDao;
import com.springbootproject.entity.Ecart;


@Service
public class CartService {
	
	@Autowired
	CartDao cd;

	public String setAllObj(List<Ecart> e) {
		return cd.setAllObj(e);
	}

	public Ecart getObj(int a) {
		return cd.getObj(a);
	}
	public List<Ecart> getAllObj() {
		return cd.getAllObj();
	}
	public String updateObj(Ecart e, int b) {
		return cd.updateObj(e,b);
	}

	public String deleteById(int e) {
		return cd.deleteById(e); 
	}
	

}
