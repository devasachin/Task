package com.springbootproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springbootproject.entity.Ecart;
import com.springbootproject.service.CartService;

@RestController
public class CartContoller {
		@Autowired
		CartService cs;
		
		@PostMapping(value="/setAllObj")
		public String setAllObj(@RequestBody List<Ecart>e) {
			return cs.setAllObj(e);
		}
		@GetMapping(value="/getObj/{a}")
		public Ecart getObj(@PathVariable int a) {
			return cs.getObj(a);
		}
		@GetMapping(value="/getAllObj")
		public List<Ecart> getallObj() {
			return cs.getAllObj();
		}
		@PutMapping(value="/update/{id}")
		public String updateObj(@RequestBody Ecart e, @PathVariable int b) {
			return cs.updateObj(e,b);
		}
		@DeleteMapping(value="/deleteById/{a}")
		public String deleteById(@PathVariable int e) {
			return cs.deleteById(e);
		}
}
