package com.springbootproject.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springbootproject.entity.Ecart;
import com.springbootproject.repository.CartRepository;

@Repository
public class CartDao {
	
	@Autowired
	CartRepository cr;
	
	public String setAllObj(List<Ecart> e) {
		cr.saveAll(e);
		return "Saved Successfully";
	}
	public Ecart getObj(int a) {
		return cr.findById(a).get();
	}
	public List<Ecart> getAllObj() {
		return cr.findAll();
	}
	public String updateObj(Ecart e, int b) {
		Ecart x=cr.findById(b).get();
		x.setCustomerName(e.getCustomerName());
		x.setMobNumber(e.getMobNumber());
		x.setCustomerAddress(e.getCustomerAddress());
		x.setProductName(e.getProductName());
		x.setProductPrice(e.getProductPrice());
		x.setProductQuantity(e.getProductQuantity());
		cr.save(x);
		return "Updated Successfully";
	}
	public String deleteById(int e) {
		 cr.deleteById(e);
		 return "Deleted Sucessfully";
	}

}
